#include <stdio.h>

int main()
{
    int NUMERO;
    int f0 = 0;
    int f1 = 1;
    int siguiente;
    int i;

    printf("Ingrese una posicion: ");
    scanf("%d", &NUMERO);

    if(NUMERO < 2)
    {
        printf("NUMERO debe ser mayor o igual a 2.\n");
        return 0;
    }

    for(i = 2; i <= NUMERO; i++)
    {
        siguiente = f0 + f1;
        f0 = f1;
        f1 = siguiente;
    }

    printf("Fibonacci en la posicion %d = %d\n", NUMERO, f1);

    return 0;
}