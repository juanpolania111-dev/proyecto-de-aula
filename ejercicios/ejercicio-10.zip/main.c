/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int main() {

    float LECTURAS_ADC[10] = {10, 20, 30, 40, 50, 60, 70, 80, 90, 100};
    float FILTRO[10];

    // Primera y segunda posición en 0
    FILTRO[0] = 0;
    FILTRO[1] = 0;

    // Promedio de la lectura actual y las dos anteriores
    for (int i = 2; i < 9; i++) {
        FILTRO[i] = (LECTURAS_ADC[i] +
                     LECTURAS_ADC[i - 1] +
                     LECTURAS_ADC[i - 2]) / 3.0;
    }

    // Última posición en 0
    FILTRO[9] = 0;

    // Mostrar las listas
    printf("LECTURAS_ADC:\n");
    for (int i = 0; i < 10; i++) {
        printf("%.2f ", LECTURAS_ADC[i]);
    }

    printf("\n\nFILTRO:\n");
    for (int i = 0; i < 10; i++) {
        printf("%.2f ", FILTRO[i]);
    }

    return 0;
}

