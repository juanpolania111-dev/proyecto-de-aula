#include <stdio.h>

int main()
{
    int NUMERO;
    int impar = 1;
    int suma = 0;
    int i;

    printf("Ingrese un numero: ");
    scanf("%d", &NUMERO);

    printf("Numeros impares: ");

    for(i = 1; i <= NUMERO; i++)
    {
        printf("%d", impar);

        if(i < NUMERO)
        {
            printf(" + ");
        }

        suma = suma + impar;
        impar = impar + 2;
    }

    printf(" = %d\n", suma);

    return 0;
}