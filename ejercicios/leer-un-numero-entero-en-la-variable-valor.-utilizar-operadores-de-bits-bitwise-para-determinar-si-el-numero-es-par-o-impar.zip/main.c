#include <stdio.h>

int main()
{
    int VALOR;

    printf("Ingrese un numero: ");
    scanf("%d", &VALOR);

    if((VALOR & 1) == 0)
    {
        printf("%d es PAR.\n", VALOR);
    }
    else
    {
        printf("%d es IMPAR.\n", VALOR);
    }

    return 0;
}
