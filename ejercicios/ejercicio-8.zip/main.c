/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int funcionLogica(int variableA, int variableB, int variableC) {
    return (variableA && variableB) || (!variableC);
}

int main() {
    int variableA, variableB, variableC, F;

    printf(" A B C | F\n");
    printf("-------|---\n");

    for (variableA = 0; variableA <= 1; variableA++) {
        for (variableB = 0; variableB <= 1; variableB++) {
            for (variableC = 0; variableC <= 1; variableC++) {

                F = funcionLogica(variableA, variableB, variableC);

                printf(" %d %d %d | %d\n",
                       variableA, variableB, variableC, F);
            }
        }
    }

    return 0;
}
