/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    unsigned char REGISTRO_ESTADO;

    scanf("%hhu", &REGISTRO_ESTADO);

    unsigned char nibble_inferior = REGISTRO_ESTADO & 0x0F;
    unsigned char bit_5 = (REGISTRO_ESTADO >> 5) & 0x01;

    printf("Nibble inferior: %u\n", nibble_inferior);
    printf("Bit 5: %u\n", bit_5);

    return 0;
}