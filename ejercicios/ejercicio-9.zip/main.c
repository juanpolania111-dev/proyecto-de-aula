/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int bit;
    int estado = 0;

    printf("Detector de secuencia 1011\n");
    printf("Ingrese bits (0 o 1). Ingrese -1 para terminar.\n\n");

    while (1) {
        printf("Ingrese un bit: ");
        scanf("%d", &bit);

        if (bit == -1) {
            break;
        }

        if (bit != 0 && bit != 1) {
            printf("Ingrese solamente 0 o 1.\n");
            continue;
        }

        switch (estado) {

            case 0:
                if (bit == 1) {
                    estado = 1;
                }
                break;

            case 1:
                if (bit == 0) {
                    estado = 2;
                } else {
                    estado = 1;
                }
                break;

            case 2:
                if (bit == 1) {
                    estado = 3;
                } else {
                    estado = 0;
                }
                break;

            case 3:
                if (bit == 1) {
                    estado = 4;
                } else {
                    estado = 2;
                }
                break;
        }

        if (estado == 4) {
            printf("Cerradura abierta\n");

            // Reiniciamos para poder detectar otra secuencia
            estado = 0;
        }
    }

    printf("Programa terminado.\n");

    return 0;
}
